class Cal:
    # 2개의 값을 전달받아서 연산을 수행
    # plus(1, 2)
    # 버튼을 누를 때마다 연산을 수행
    # plus(1)

    #이니셜라이저 : 객체가 생성될 때 마다.
    #            멤버변수의 값을 넣어줌(초기화)
    #멤버변수

    #멤버함수
    def plus(self, n1, n2):
        return n1 + n2
    def minus(self, n1, n2):
        return n1 - n2
    def mul(self, n1, n2):
        return n1 * n2
    def div(self, n1, n2):
        return n1 / n2
