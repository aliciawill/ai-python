today = '오늘은 목요일입니다. 코로나검사해야합니다.'
print(today.find('검사'))
print('검사' in today)