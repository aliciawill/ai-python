hobby = [] #list()
hobby.append('운동')
hobby.append('달리기')
hobby.append('자전거')
print(hobby)
print(len(hobby))

for x in hobby: #['운동', '달리기', '자전거']
    print('내가 좋아하는 운동은 ', x)


