from inherit.mobile import *
# from inherit.mobile import Phone, ApplePhone, SamsungPhone

ss = SamsungPhone()
apple = ApplePhone()

ss.name = '홍길동'
ss.call()
ss.internet(3)

apple.size = 11
apple.text()
apple.youtube(2, '스포츠')
apple.youtube(1)

