import function.fun02 as f02
import function.inernet.crawl as web

f02.call1()
web.connect()