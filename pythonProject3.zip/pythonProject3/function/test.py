data = input('data >> ')
print(data.isdigit())
print(data.isalpha())

## 다음 함수를 정의하고 호출해서 확인
##