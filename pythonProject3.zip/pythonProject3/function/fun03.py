# python은 다른 모듈에 있는 함수, 클래스를
# 사용할 때는 import해주어야 어디에 있는지
# 위치를 찾는다.
import function.fun02 as f02
import function.fun01 as f01
# import 패키지.모듈명(파이썬파일명)

f02.call1()
