
# 정의 -> 호출, 호출, 호출
# 함수의 3가지 구성요소: 입력, 처리내용, 반환
def call1():
    print('나를 불렀군요.')
    print('또 나를 불렀군요.')
    return 'ok'

if __name__ == '__main__':
    call1()
    call1()
    call1()