from function.exam.tour import spring, summer

spring(4, '제주도')

result = summer('울릉도', 7)
print(result)

result2 = summer('울릉도', 11)
print(result2)