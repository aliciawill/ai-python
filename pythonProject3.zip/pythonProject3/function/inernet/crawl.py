def connect():
    print('네이버 증권 사이트를 연결하다.')
    print('네이버 증권 사이트를 받아오다.')
    print('네이버 증권 사이트를 추출하다.')

def find():
    print('html dom tree에서 원하는 데이터를 찾다.')