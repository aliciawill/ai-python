print('welcome')
print('welcome2')
print('welcome3')
print('welcome4')

# 절차적 언어의 특징을 가짐.
# 절차(순서)에 따라 실행되는 특징을 가짐.