import turtle

t = turtle.Pen()

for _ in range(50):
    t.right(110)
    t.forward(300)
